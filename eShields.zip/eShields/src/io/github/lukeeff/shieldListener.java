package io.github.lukeeff;

import java.util.HashMap;
import java.util.UUID;
import java.util.concurrent.TimeUnit;

import org.bukkit.Bukkit;
import org.bukkit.Color;
import org.bukkit.Location;
import org.bukkit.Particle;
import org.bukkit.Sound;
import org.bukkit.Particle.DustOptions;
import org.bukkit.boss.BarColor;
import org.bukkit.boss.BarStyle;
import org.bukkit.boss.BossBar;
import org.bukkit.entity.Entity;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityDamageEvent;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.scheduler.BukkitRunnable;

public class shieldListener implements Listener {
	eShields plugin;

	public shieldListener(eShields instance) {
		plugin = instance;
	}

	private final shieldCooldown shieldCooldown = new shieldCooldown();
	@SuppressWarnings("rawtypes")
	HashMap<UUID, HashMap> data = new HashMap<UUID, HashMap>();

	@EventHandler
	public void shieldDamage(EntityDamageEvent event) {
		Entity e = event.getEntity();
		double damage = event.getDamage();
		if (e instanceof Player) {
			double shield_damage = (damage / 100);
			Player player = (Player) e;
			shieldCooldown.setCooldown(player.getUniqueId(), System.currentTimeMillis());
			BossBar playerShield = (BossBar) data.get(player.getUniqueId()).get("shieldMap");
			playerShield.addPlayer(player);
			Bukkit.getScheduler().runTaskLater(plugin, () -> restoreShield(player.getUniqueId(), playerShield), 101);
			if (playerShield.getProgress() >= 0.001) {
				try {
					playerShield.setProgress(playerShield.getProgress() - shield_damage * 5);
					event.setDamage(shield_damage);
				} catch (Exception ex) {
					playerShield.setColor(BarColor.RED);
					event.setDamage((((shield_damage * 5) - playerShield.getProgress()) * 20));
					playerShield.setProgress(0);
					// player.setLastDamage((((shield_damage * 5) - shield.getProgress()) * 20));
					// player.spawnParticle(Particle.CRIT, player.getLocation(), 50);
					player.playSound(player.getLocation(), Sound.BLOCK_ANVIL_LAND, 0.5f, .85f);
				}
			} else {
				playerShield.setColor(BarColor.RED);
			}
		}

	}

	public void restoreShield(UUID p, BossBar playerShield) {
		Player player = Bukkit.getPlayer(p);
		
		long timeLeft = System.currentTimeMillis() - shieldCooldown.getCooldown(player.getUniqueId());
		if (TimeUnit.MILLISECONDS.toSeconds(timeLeft) >= io.github.lukeeff.shieldCooldown.DEFAULT_COOLDOWN) {
			haloEffect(player, playerShield);
			player.playSound(player.getLocation(), Sound.BLOCK_BEACON_ACTIVATE, 1f, .4f);
			new BukkitRunnable() {

				double step = 0.01;

				@Override
				public void run() {
					//player.spawnParticle(Particle.CRIT, player.getLocation().add(0, Math.random() + 0.4, 0), 0,
					//		Math.random() - 0.6, Math.random() - 0.6, Math.random() - 0.6);
					long timeLeft = System.currentTimeMillis() - shieldCooldown.getCooldown(player.getUniqueId());

					if (TimeUnit.MILLISECONDS.toSeconds(timeLeft) >= io.github.lukeeff.shieldCooldown.DEFAULT_COOLDOWN
							& playerShield.getProgress() < 1) {
						if (playerShield.getProgress() + step < 1) {
							playerShield.setProgress(playerShield.getProgress() + step);
						} else {
							playerShield.setProgress(1);
						}
					} else {
						this.cancel();
					}
				}
			}.runTaskTimer(plugin, 0L, 1L);

		}

	}

	public void haloEffect(Player player, BossBar playerShield) {
		int radius = 1;

		new BukkitRunnable() {
			double y = 0;
			DustOptions dustOptions = new DustOptions(Color.fromRGB(253, 249, 99), 1);

			@Override
			public void run() {
				Location loc = player.getLocation();
				double z = radius * Math.sin(4 * y);
				double x = radius * Math.cos(4 * y);
				player.spawnParticle(Particle.REDSTONE, loc.getX() + x / 2, loc.getY() + y, loc.getZ() + z / 2, 5,
						dustOptions);
				long timeLeft = System.currentTimeMillis() - shieldCooldown.getCooldown(player.getUniqueId());
				if (y >= 2) {
					y = 0;
				} else {
					y = y + 0.05;
				}

				if (TimeUnit.MILLISECONDS.toSeconds(timeLeft) >= io.github.lukeeff.shieldCooldown.DEFAULT_COOLDOWN
						& playerShield.getProgress() < 1) {

				} else {
					this.cancel();
				}
			}
		}.runTaskTimer(plugin, 0L, 1L);

	}

	@EventHandler
	public void onJoin(PlayerJoinEvent event) {
		Player player = (Player) event.getPlayer();
		UUID pID = player.getUniqueId();
		int timeSinceHit = 0;
		// long shieldTime = plugin.config.getLong("Regeneration_Time");
		// double shieldValue = 30; // remove this after adding to config <--
		BossBar shield = Bukkit.createBossBar("Shield Status", BarColor.BLUE, BarStyle.SOLID);
		shield.setProgress(1);
		HashMap<String, Object> contents = new HashMap<String, Object>();
		// Throws objects into HashMap unique to player UUID.
		contents.put("shieldMap", shield);
		contents.put("timeMap", timeSinceHit);
		data.put(pID, contents);
		// Visualizes the boss shield.
		shield.addPlayer(player);
		shield.setVisible(true);

	}

}