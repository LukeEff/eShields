package io.github.lukeeff;

import java.util.HashMap;
import java.util.UUID;

import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.plugin.java.JavaPlugin;

public class eShields extends JavaPlugin {

	FileConfiguration config = this.getConfig();

	@SuppressWarnings("rawtypes")
	HashMap<UUID, HashMap> data = new HashMap<>();

	@Override
	public void onEnable() {

		configDefaults();
		getServer().getPluginManager().registerEvents(new shieldListener(this), this);
		this.getCommand("shield").setExecutor(new commandExecutor());
	}

	@Override
	public void onDisable() {

	}

	void configDefaults() {

		config.addDefault("Shield_Health", 30.0);
		config.addDefault("Regeneration_Time", 40.0);
		config.options().copyDefaults(true);
		saveConfig();

	}
/*
	public HashMap populateData(UUID playerID, double shieldvalue, long shieldTime) {

    	HashMap <Double,Long> data = new HashMap<>();
    	data.put(shieldvalue, shieldTime);
    	
    	data = {
    		'player1id': {
    	    	'value': 42,
    	    	'time': 99
    		},
    		'player2id': {
        		'value': 42,
        		'time': 99
        	},
    	}
		return data;
    	
    	
    	Object sheildcity {
    	}
    	
    	UUID, HAshmap>
    	Object, Hashmap
    	Object, HAshmap
    	
    	
    }
*/

	
}
