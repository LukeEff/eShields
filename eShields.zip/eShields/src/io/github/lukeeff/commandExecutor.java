package io.github.lukeeff;

import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.boss.BarColor;
import org.bukkit.boss.BarStyle;
import org.bukkit.boss.BossBar;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Entity;
import org.bukkit.entity.EntityType;
import org.bukkit.entity.Player;

public class commandExecutor implements CommandExecutor {
	
	
		
	@Override
	public boolean onCommand(CommandSender sender, Command cmd, String arg0, String[] args) {
		// TODO create shield for player on command with value in configuration.
		
		
        if (sender instanceof Player) {
        	
        	
            Player player = (Player) sender;
            Location loc = player.getLocation();
            //final Entity shield = loc.getWorld().spawnEntity(loc, EntityType.WITHER_SKULL);
            //EntityType chargedC = EntityType.CREEPER;
            loc.getWorld().spawnEntity(loc, EntityType.WITHER_SKULL);
            
            
        }

        // If the player (or console) uses our command correct, we can return true
        return true;
	}

	
}
